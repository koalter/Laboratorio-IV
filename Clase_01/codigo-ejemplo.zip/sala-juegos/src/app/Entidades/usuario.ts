export class Usuario {
    public nombre: string|undefined;
    public apellido: string|undefined;

    public mostrar(): void {
        console.log(`Nombre: ${this.nombre}. Apellido: ${this.apellido}`);
    }
}
