import { Component, OnInit } from '@angular/core';
import { Usuario } from 'src/app/Entidades/usuario';

@Component({
  selector: 'app-juego',
  templateUrl: './juego.component.html',
  styleUrls: ['./juego.component.scss']
})
export class JuegoComponent implements OnInit {

  public usuario: Usuario = new Usuario();

  constructor() { 
  }

  ngOnInit(): void {
    this.usuario.nombre = "Lorenzo";
    this.usuario.apellido = "Cea";
  }

  cambiarNombre(): void {
    this.usuario.nombre = "Nahuel";
  }

}
